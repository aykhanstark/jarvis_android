package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.SmsManager
import android.util.Log
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var conversation: TextView
    private lateinit var scrollView: ScrollView
    private lateinit var statusLabel: TextView
    private lateinit var micBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var clearBtn: Button

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var voiceOn = true
    private var isListening = false
    private var isBusy = false
    private var ttsReady = false

    private val history = mutableListOf<Pair<String, String>>() // role, content
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val neededPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.SEND_SMS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                runOnUiThread { showCrashScreen(throwable) }
            } catch (ignored: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }

        try {
            setContentView(R.layout.activity_main)

            conversation = findViewById(R.id.conversation)
            scrollView = findViewById(R.id.scrollView)
            statusLabel = findViewById(R.id.statusLabel)
            micBtn = findViewById(R.id.micBtn)
            muteBtn = findViewById(R.id.muteBtn)
            clearBtn = findViewById(R.id.clearBtn)

            requestMissingPermissions()
            setupTts()
            setupRecognizer()

            micBtn.setOnClickListener { onMicTapped() }
            muteBtn.setOnClickListener {
                voiceOn = !voiceOn
                muteBtn.text = if (voiceOn) "SƏS: AÇIQ" else "SƏS: BAĞLI"
                if (!voiceOn) tts?.stop()
            }
            clearBtn.setOnClickListener {
                history.clear()
                conversation.text = "Sıfırlandı. Dinləyirəm."
            }
        } catch (t: Throwable) {
            showCrashScreen(t)
        }
    }

    private fun showCrashScreen(t: Throwable) {
        Log.e("JARVIS_CRASH", "onCreate xətası", t)
        val tv = TextView(this).apply {
            text = "JARVIS BAŞLADILA BİLMƏDİ.\nBu mətni screenshot alıb göndər:\n\n" + Log.getStackTraceString(t)
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.BLACK)
            textSize = 11f
            setPadding(24, 60, 24, 24)
        }
        setContentView(android.widget.ScrollView(this).apply { addView(tv) })
    }

    private fun requestMissingPermissions() {
        val missing = neededPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
        }
    }

    // ---------- TTS ----------
    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        runOnUiThread { setStatus("YANITLIYOR") }
                    }
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            setStatus("HAZIR")
                            // Cavab bitən kimi özü yenidən dinləməyə başlasın - əsl Jarvis kimi
                            startListening()
                        }
                    }
                    override fun onError(utteranceId: String?) {
                        runOnUiThread { setStatus("HAZIR") }
                    }
                })
            }
        }
    }

    private fun speak(text: String) {
        if (!voiceOn || !ttsReady) return
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utt_${System.currentTimeMillis()}")
    }

    // ---------- Speech recognition ----------
    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                runOnUiThread { setStatus("DİNLİYOR") }
            }
            override fun onEndOfSpeech() {
                isListening = false
            }
            override fun onError(error: Int) {
                isListening = false
                runOnUiThread {
                    setStatus("HAZIR")
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        // sakitlik - sükutla gözlə, istifadəçi mikrofona təkrar toxuna bilər
                    } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        appendLine("JARVIS", "Mikrofon icazəsi verilməyib. Ayarlardan icazə ver.")
                    }
                }
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    handleUserInput(text.trim())
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onBeginningOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun onMicTapped() {
        if (isBusy) return
        tts?.stop()
        startListening()
    }

    private fun startListening() {
        if (isBusy || isListening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e("JARVIS", "startListening hatası", e)
        }
    }

    private fun setStatus(s: String) {
        statusLabel.text = s
    }

    private fun appendLine(who: String, text: String) {
        conversation.append("\n\n$who: $text")
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // ---------- Komanda təhlili: zəng / mesaj / proqram aç / budilnik ----------
    private fun handleUserInput(text: String) {
        appendLine("SƏN", text)
        val lower = text.lowercase(Locale.getDefault())

        when {
            Regex("z[əe]ng|ara |ara$|çağır").containsMatchIn(lower) -> handleCallCommand(lower)
            Regex("mesaj|yaz .* de ki|sms").containsMatchIn(lower) -> handleSmsCommand(lower, text)
            Regex("budilnik|alarm").containsMatchIn(lower) -> handleAlarmCommand(lower)
            Regex("^aç |^open |proqramını aç|tətbiqini aç").containsMatchIn(lower) -> handleOpenAppCommand(lower)
            else -> askClaude(text)
        }
    }

    private fun cleanName(raw: String, keywords: List<String>): String {
        var n = raw
        keywords.forEach { n = n.replace(it, " ", ignoreCase = true) }
        return n.trim().trim('.', ',', '!', '?')
    }

    // ---- Zəng ----
    private fun handleCallCommand(lower: String) {
        val name = cleanName(lower, listOf("zəng et", "zəng elə", "zəng eyle", "zəng eyl", "ara", "çağır"))
        if (name.isBlank()) {
            speakAndShow("Kimə zəng edim?")
            return
        }
        val number = findContactPhoneNumber(name)
        if (number == null) {
            speakAndShow("$name adlı kontakt tapılmadı.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            try {
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
                speakAndShow("$name-ə zəng edilir.")
            } catch (e: SecurityException) {
                speakAndShow("Zəng icazəsi yoxdur.")
            }
        } else {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
            speakAndShow("$name üçün nömrəni açdım, zəng et düyməsinə bas.")
        }
    }

    private fun findContactPhoneNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$name%")
        contentResolver.query(uri, projection, selection, args, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return cursor.getString(numberIdx)
            }
        }
        return null
    }

    // ---- SMS ----
    private fun handleSmsCommand(lower: String, original: String) {
        // Nümunə: "Elvinə mesaj göndər salam necəsən" -> ad = Elvin, mesaj = "salam necəsən"
        val cleaned = cleanName(lower, listOf("mesaj göndər", "mesaj yolla", "sms göndər", "sms"))
        val parts = cleaned.trim().split(" ", limit = 2)
        val name = parts.getOrNull(0) ?: ""
        val message = parts.getOrNull(1) ?: ""
        if (name.isBlank() || message.isBlank()) {
            speakAndShow("Kimə və nə mesajı göndərim?")
            return
        }
        val number = findContactPhoneNumber(name)
        if (number == null) {
            speakAndShow("$name adlı kontakt tapılmadı.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(number, null, message, null, null)
                speakAndShow("$name-ə mesaj göndərildi.")
            } catch (e: Exception) {
                speakAndShow("Mesaj göndərilmədi: ${e.message}")
            }
        } else {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                putExtra("sms_body", message)
            }
            startActivity(intent)
        }
    }

    // ---- Proqram açmaq ----
    private fun handleOpenAppCommand(lower: String) {
        val target = cleanName(lower, listOf("aç", "open", "proqramını", "tətbiqini")).trim()
        if (target.isBlank()) {
            speakAndShow("Hansı proqramı açım?")
            return
        }
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(target)
        }
        if (match != null) {
            val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (launch != null) {
                startActivity(launch)
                speakAndShow("${match.loadLabel(pm)} açılır.")
                return
            }
        }
        speakAndShow("\"$target\" adlı proqram tapılmadı.")
    }

    // ---- Budilnik ----
    private fun handleAlarmCommand(lower: String) {
        val timeMatch = Regex("(\\d{1,2})[:.](\\d{2})").find(lower)
        val hourOnlyMatch = Regex("saat\\s*(\\d{1,2})").find(lower)
        var hour: Int
        var minute = 0
        if (timeMatch != null) {
            hour = timeMatch.groupValues[1].toInt()
            minute = timeMatch.groupValues[2].toInt()
        } else if (hourOnlyMatch != null) {
            hour = hourOnlyMatch.groupValues[1].toInt()
        } else {
            speakAndShow("Saat neçəyə budilnik qurum?")
            return
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        try {
            startActivity(intent)
            speakAndShow(String.format("Saat %02d:%02d üçün budilnik quruldu.", hour, minute))
        } catch (e: Exception) {
            speakAndShow("Budilnik qura bilmədim.")
        }
    }

    private fun speakAndShow(text: String) {
        appendLine("JARVIS", text)
        history.add("assistant" to text)
        speak(text)
    }

    // ---- Claude ilə sərbəst söhbət ----
    private fun askClaude(text: String) {
        isBusy = true
        setStatus("İŞLƏNİYOR")
        history.add("user" to text)
        if (history.size > 20) {
            while (history.size > 20) history.removeAt(0)
        }

        val baseUrl = getString(R.string.server_base_url).trimEnd('/')
        val systemPrompt = "Sen JARVIS adında kişisel sesli asistansın. Sakin, zeki, kısa ve öz cevap ver. " +
                "Yanıtların sesli okunacak, 1-3 cümleyi geçme, markdown kullanma. Kullanıcının konuştuğu dilde cevap ver."

        val messagesArray = JSONArray()
        history.forEach { (role, content) ->
            messagesArray.put(JSONObject().put("role", role).put("content", content))
        }
        val payload = JSONObject().apply {
            put("system", systemPrompt)
            put("messages", messagesArray)
        }

        val body = payload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("$baseUrl/api/chat").post(body).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    isBusy = false
                    setStatus("HAZIR")
                    speakAndShow("Bağlantı hatası: ${e.message}")
                }
            }
            override fun onResponse(call: Call, response: Response) {
                val bodyStr = response.body?.string() ?: "{}"
                runOnUiThread {
                    isBusy = false
                    setStatus("HAZIR")
                    try {
                        val json = JSONObject(bodyStr)
                        if (!response.isSuccessful) {
                            val err = json.optString("error", "Sunucu hatası (${response.code})")
                            speakAndShow(err)
                            return@runOnUiThread
                        }
                        val contentArr = json.optJSONArray("content")
                        val reply = StringBuilder()
                        if (contentArr != null) {
                            for (i in 0 until contentArr.length()) {
                                val block = contentArr.getJSONObject(i)
                                if (block.has("text")) reply.append(block.getString("text")).append(" ")
                            }
                        }
                        val replyText = reply.toString().trim().ifBlank { "Şu an cevap veremiyorum." }
                        speakAndShow(replyText)
                    } catch (e: Exception) {
                        speakAndShow("Yanıt işlenemedi: ${e.message}")
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
